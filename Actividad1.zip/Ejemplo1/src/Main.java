import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Fruit> fruitList = new ArrayList<Fruit>();
        Random random = new Random();
        int option;
        System.out.println(":::::::::::::::::::::::::::::::::::::::");
        System.out.println("WELCOME TO YOUR FAVORITE FRUIT'S STORE");
        do {
            System.out.println(":::::::::::::::::::::::::::::::::::::::");
            System.out.println("1. Add/ create fruits");
            System.out.println("2. Go to checkout ( fruits' quantity and  prices)");
            System.out.println("3. Exit");
            System.out.println("Note: at checkout you'll find quantity of fruits that you picked and their prices");
            System.out.print("Choose one option: ");
            option = sc.nextInt();
            sc.nextLine();

            switch (option) {
                case 1:
                    String[] fruits = {"Apple", "Mango", "Strawberry", "Pear"};

                    System.out.println(":::::::::::::::::::::::::::::::::::::::");
                    System.out.println("Fruits availables: ");
                    for (int i = 0; i < fruits.length; i++) {
                        System.out.println((i + 1) + ". " + fruits[i]);
                    }

                    System.out.println(":::::::::::::::::::::::::::::::::::::::");
                    System.out.print("Type a number between 1 and 4 based on the fruit you'd like to add: ");
                    int option2 = sc.nextInt();
                    sc.nextLine();

                    String name = fruits[option2 - 1];
                    System.out.println(":::::::::::::::::::::::::::::::::::::::");
                    System.out.print("How many " + name + " do you want? ");
                    int amount = sc.nextInt();
                    sc.nextLine();

                    double price = (random.nextInt(1000000 - 1000 + 1) /100);
                    Fruit fruit = new Fruit(name, amount, price);
                    fruitList.add(fruit);

                    System.out.println("Fruit successfully added!!");

                    break;

                case 2:
                    System.out.println(":::::::::::::::::::::::::::::::::::::::");
                    System.out.println("CHECKOUT: ");
                    System.out.println("Quantity and prices: ");
                    double totalCart = 0;
                    System.out.println(":::::::::::::::::::::::::::::::::::::::");
                    for (Fruit f : fruitList) {
                        System.out.println(" °" + f.getName() + " : $ " + f.getPrice() + " Quantity: " + f.getAmount());
                        System.out.println("Total for  " + f.getName() + " :  $ " + (f.getPrice() * f.getAmount()));
                        totalCart += f.getPrice() * f.getAmount();
                    }

                    System.out.println("TOTAL AMOUNT YOU OWN: $" + totalCart);
                    System.out.println(":::::::::::::::::::::::::::::::::::::::");
                    break;
            }

        }
            while (option != 3) ;
            System.out.println("See you later!");
            System.out.println(":::::::::::::::::::::::::::::::::::::::");
            sc.close();
    }
}